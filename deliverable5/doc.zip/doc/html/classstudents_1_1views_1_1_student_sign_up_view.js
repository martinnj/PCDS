var classstudents_1_1views_1_1_student_sign_up_view =
[
    [ "form_invalid", "classstudents_1_1views_1_1_student_sign_up_view.html#afbf2ab8d301bfa81d6c9800ad4216667", null ],
    [ "form_valid", "classstudents_1_1views_1_1_student_sign_up_view.html#af327972736edd8cd1d9df42c6d44c2a1", null ]
];