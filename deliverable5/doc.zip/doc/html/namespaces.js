var namespaces =
[
    [ "students", "namespacestudents.html", "namespacestudents" ]
];