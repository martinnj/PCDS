var classstudents_1_1views_1_1_update_student_profile_view =
[
    [ "form_invalid", "classstudents_1_1views_1_1_update_student_profile_view.html#adf9774ac477073f89833c930a725280c", null ],
    [ "form_valid", "classstudents_1_1views_1_1_update_student_profile_view.html#a102eb919b1750833c189b66b1442771b", null ]
];