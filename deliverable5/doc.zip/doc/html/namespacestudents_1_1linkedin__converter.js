var namespacestudents_1_1linkedin__converter =
[
    [ "Person", "classstudents_1_1linkedin__converter_1_1_person.html", "classstudents_1_1linkedin__converter_1_1_person" ],
    [ "Language", "classstudents_1_1linkedin__converter_1_1_language.html", null ],
    [ "Position", "classstudents_1_1linkedin__converter_1_1_position.html", null ],
    [ "Course", "classstudents_1_1linkedin__converter_1_1_course.html", null ],
    [ "Skill", "classstudents_1_1linkedin__converter_1_1_skill.html", null ],
    [ "Education", "classstudents_1_1linkedin__converter_1_1_education.html", null ]
];