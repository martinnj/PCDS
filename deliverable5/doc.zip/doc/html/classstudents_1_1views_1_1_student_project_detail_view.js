var classstudents_1_1views_1_1_student_project_detail_view =
[
    [ "get_queryset", "classstudents_1_1views_1_1_student_project_detail_view.html#aa6147461550ece1940834db56b32960f", null ]
];