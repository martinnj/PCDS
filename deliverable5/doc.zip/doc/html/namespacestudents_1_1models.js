var namespacestudents_1_1models =
[
    [ "Student", "classstudents_1_1models_1_1_student.html", "classstudents_1_1models_1_1_student" ],
    [ "StudentProjectManager", "classstudents_1_1models_1_1_student_project_manager.html", "classstudents_1_1models_1_1_student_project_manager" ],
    [ "StudentProject", "classstudents_1_1models_1_1_student_project.html", null ],
    [ "LinkedInProfile", "classstudents_1_1models_1_1_linked_in_profile.html", "classstudents_1_1models_1_1_linked_in_profile" ],
    [ "Language", "classstudents_1_1models_1_1_language.html", "classstudents_1_1models_1_1_language" ],
    [ "Course", "classstudents_1_1models_1_1_course.html", "classstudents_1_1models_1_1_course" ],
    [ "Skill", "classstudents_1_1models_1_1_skill.html", "classstudents_1_1models_1_1_skill" ],
    [ "Education", "classstudents_1_1models_1_1_education.html", "classstudents_1_1models_1_1_education" ],
    [ "Position", "classstudents_1_1models_1_1_position.html", "classstudents_1_1models_1_1_position" ]
];