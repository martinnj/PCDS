var classstudents_1_1views_1_1_student_view =
[
    [ "dispatch", "classstudents_1_1views_1_1_student_view.html#ab04c41f2121d32a620fea480ca8dd538", null ],
    [ "get_context_data", "classstudents_1_1views_1_1_student_view.html#aea33d4cd9db8ef7b1caf79b8c4502a94", null ]
];