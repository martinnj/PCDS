var classstudents_1_1views_1_1_student_f_a_q_view =
[
    [ "get_queryset", "classstudents_1_1views_1_1_student_f_a_q_view.html#ab7a8f396a3327b1aec9bbaf3e28efb9e", null ]
];