var classstudents_1_1views_1_1_student_project_creation_view =
[
    [ "dispatch", "classstudents_1_1views_1_1_student_project_creation_view.html#abab72acbf11b726e50eb44f97965430c", null ],
    [ "form_valid", "classstudents_1_1views_1_1_student_project_creation_view.html#a3b2f139feec7b5eb7cc843c85355a4e5", null ]
];