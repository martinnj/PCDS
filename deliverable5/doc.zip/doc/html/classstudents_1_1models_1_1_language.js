var classstudents_1_1models_1_1_language =
[
    [ "__unicode__", "classstudents_1_1models_1_1_language.html#a656e053c3a3adce525fb3a3b000d08b1", null ],
    [ "get_language", "classstudents_1_1models_1_1_language.html#a5b15a386a956f22ce3507f94f57cbf60", null ]
];