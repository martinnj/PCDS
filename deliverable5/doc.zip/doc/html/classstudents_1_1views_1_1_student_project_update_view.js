var classstudents_1_1views_1_1_student_project_update_view =
[
    [ "form_valid", "classstudents_1_1views_1_1_student_project_update_view.html#a6691a76d37261d83f717cfd00103fc26", null ]
];