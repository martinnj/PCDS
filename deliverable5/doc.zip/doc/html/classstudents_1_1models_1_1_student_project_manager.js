var classstudents_1_1models_1_1_student_project_manager =
[
    [ "get_own_drafts_queryset", "classstudents_1_1models_1_1_student_project_manager.html#abd14aa2f19159a52589e99a1efbdc28d", null ],
    [ "get_own_projects", "classstudents_1_1models_1_1_student_project_manager.html#ad3c648c438aa4d5843bd6c126c392447", null ],
    [ "get_own_published_queryset", "classstudents_1_1models_1_1_student_project_manager.html#aabfcebd98ffe329aa15c4776dea7ce95", null ],
    [ "get_published_queryset", "classstudents_1_1models_1_1_student_project_manager.html#a03b6388a1e607fe19f5a936cc6413aa7", null ]
];