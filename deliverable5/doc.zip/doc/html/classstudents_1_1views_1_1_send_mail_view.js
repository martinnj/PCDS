var classstudents_1_1views_1_1_send_mail_view =
[
    [ "form_valid", "classstudents_1_1views_1_1_send_mail_view.html#a1a31847593c140f09be550af7e3db59a", null ],
    [ "get_context_data", "classstudents_1_1views_1_1_send_mail_view.html#a41cb4edae96b73f4a14a62bbe3e02b3f", null ]
];