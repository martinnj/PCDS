var searchData=
[
  ['bachelor',['BACHELOR',['../classstudents_1_1models_1_1_student.html#a44c22f24f6430caa8c30a11cc2eda2f9',1,'students::models::Student']]]
];
