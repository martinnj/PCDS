var searchData=
[
  ['date_5fjoined',['date_joined',['../classstudents_1_1models_1_1_student.html#a904985debef148d1871397fbdd756c91',1,'students::models::Student']]],
  ['date_5fof_5fbirth',['date_of_birth',['../classstudents_1_1models_1_1_student.html#af7f5dc2a714b4a00ceac864f96a5126c',1,'students::models::Student']]],
  ['degree',['degree',['../classstudents_1_1linkedin__converter_1_1_education.html#a95e740f34b15f9f118e5b33d5058bd08',1,'students.linkedin_converter.Education.degree()'],['../classstudents_1_1models_1_1_education.html#a32495524f30233cc0f398a859edfc239',1,'students.models.Education.degree()']]],
  ['department',['department',['../classstudents_1_1models_1_1_student.html#ab9b3060609019e2bc54a43d2e09c0cbd',1,'students::models::Student']]],
  ['description',['description',['../classstudents_1_1models_1_1_student.html#a56967491948903227152a9fa074c9546',1,'students::models::Student']]],
  ['dispatch',['dispatch',['../classstudents_1_1views_1_1_student_view.html#ab04c41f2121d32a620fea480ca8dd538',1,'students.views.StudentView.dispatch()'],['../classstudents_1_1views_1_1_student_own_project_list_view.html#a1914d88da030233e5bde8e9eaa672d1f',1,'students.views.StudentOwnProjectListView.dispatch()'],['../classstudents_1_1views_1_1_student_project_creation_view.html#abab72acbf11b726e50eb44f97965430c',1,'students.views.StudentProjectCreationView.dispatch()'],['../classstudents_1_1views_1_1_list_all_projects_view.html#a0d33266bd02b1a7db4bcadb7013a02ad',1,'students.views.ListAllProjectsView.dispatch()'],['../classstudents_1_1views_1_1_all_project_detail_view.html#ab4579ea6b73991a980aaf7d0d7e373e8',1,'students.views.AllProjectDetailView.dispatch()']]]
];
