var searchData=
[
  ['parseskills',['parseSkills',['../namespacestudents_1_1matchmaking.html#aac73f2cefa7cada176cc1d3896416edc',1,'students::matchmaking']]],
  ['printprojects',['printProjects',['../namespacestudents_1_1matchmaking.html#a3f28ed62649ae8f076cebb31d838a64a',1,'students::matchmaking']]]
];
