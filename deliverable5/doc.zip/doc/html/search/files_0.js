var searchData=
[
  ['admin_2epy',['admin.py',['../admin_8py.html',1,'']]]
];
