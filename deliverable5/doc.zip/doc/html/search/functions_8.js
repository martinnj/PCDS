var searchData=
[
  ['matchlistsofstrings',['matchListsOfStrings',['../namespacestudents_1_1matchmaking.html#af3e519980cd77aceb9fe2a6843ed0eac',1,'students::matchmaking']]]
];
