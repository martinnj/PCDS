var searchData=
[
  ['dispatch',['dispatch',['../classstudents_1_1views_1_1_student_view.html#ab04c41f2121d32a620fea480ca8dd538',1,'students.views.StudentView.dispatch()'],['../classstudents_1_1views_1_1_student_own_project_list_view.html#a1914d88da030233e5bde8e9eaa672d1f',1,'students.views.StudentOwnProjectListView.dispatch()'],['../classstudents_1_1views_1_1_student_project_creation_view.html#abab72acbf11b726e50eb44f97965430c',1,'students.views.StudentProjectCreationView.dispatch()'],['../classstudents_1_1views_1_1_list_all_projects_view.html#a0d33266bd02b1a7db4bcadb7013a02ad',1,'students.views.ListAllProjectsView.dispatch()'],['../classstudents_1_1views_1_1_all_project_detail_view.html#ab4579ea6b73991a980aaf7d0d7e373e8',1,'students.views.AllProjectDetailView.dispatch()']]]
];
