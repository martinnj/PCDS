var searchData=
[
  ['unique_5fslugify',['unique_slugify',['../classstudents_1_1models_1_1_student.html#ab1ff0197cbfbdbfac52b54a9bc51e592',1,'students::models::Student']]],
  ['updatestudentprofileview',['UpdateStudentProfileView',['../classstudents_1_1views_1_1_update_student_profile_view.html',1,'students::views']]],
  ['urls_2epy',['urls.py',['../urls_8py.html',1,'']]],
  ['user',['user',['../classstudents_1_1models_1_1_student.html#a7c56f44c930c1bcdd80f8f8860af5bee',1,'students::models::Student']]],
  ['userskills',['userSkills',['../namespacestudents_1_1matchmaking.html#a53165c9d3c68ba55847f8301028564e3',1,'students::matchmaking']]]
];
