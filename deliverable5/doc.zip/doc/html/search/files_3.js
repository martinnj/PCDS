var searchData=
[
  ['urls_2epy',['urls.py',['../urls_8py.html',1,'']]]
];
