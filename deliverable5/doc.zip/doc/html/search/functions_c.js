var searchData=
[
  ['unique_5fslugify',['unique_slugify',['../classstudents_1_1models_1_1_student.html#ab1ff0197cbfbdbfac52b54a9bc51e592',1,'students::models::Student']]]
];
