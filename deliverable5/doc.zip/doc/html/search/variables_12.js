var searchData=
[
  ['user',['user',['../classstudents_1_1models_1_1_student.html#a7c56f44c930c1bcdd80f8f8860af5bee',1,'students::models::Student']]],
  ['userskills',['userSkills',['../namespacestudents_1_1matchmaking.html#a53165c9d3c68ba55847f8301028564e3',1,'students::matchmaking']]]
];
