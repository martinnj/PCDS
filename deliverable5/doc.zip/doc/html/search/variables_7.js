var searchData=
[
  ['gender',['gender',['../classstudents_1_1models_1_1_student.html#ae8f0e56e008cc61770d2f0f5b5ca6182',1,'students::models::Student']]]
];
