var searchData=
[
  ['insert_5flinkedin_5fprofile',['insert_linkedin_profile',['../namespacestudents_1_1models.html#ae5c93301e2a2e140c9b76452f5b2c79d',1,'students::models']]]
];
