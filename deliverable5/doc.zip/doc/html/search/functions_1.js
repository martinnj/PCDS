var searchData=
[
  ['all_5fprojects_5ffilter',['all_projects_filter',['../namespacestudents_1_1views.html#a021cba8bff39e0d31e6a5357dba3e328',1,'students::views']]]
];
