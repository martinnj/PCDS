var searchData=
[
  ['allprojectdetailview',['AllProjectDetailView',['../classstudents_1_1views_1_1_all_project_detail_view.html',1,'students::views']]]
];
