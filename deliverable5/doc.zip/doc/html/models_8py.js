var models_8py =
[
    [ "Student", "classstudents_1_1models_1_1_student.html", "classstudents_1_1models_1_1_student" ],
    [ "StudentProjectManager", "classstudents_1_1models_1_1_student_project_manager.html", "classstudents_1_1models_1_1_student_project_manager" ],
    [ "StudentProject", "classstudents_1_1models_1_1_student_project.html", null ],
    [ "LinkedInProfile", "classstudents_1_1models_1_1_linked_in_profile.html", "classstudents_1_1models_1_1_linked_in_profile" ],
    [ "Language", "classstudents_1_1models_1_1_language.html", "classstudents_1_1models_1_1_language" ],
    [ "Course", "classstudents_1_1models_1_1_course.html", "classstudents_1_1models_1_1_course" ],
    [ "Skill", "classstudents_1_1models_1_1_skill.html", "classstudents_1_1models_1_1_skill" ],
    [ "Education", "classstudents_1_1models_1_1_education.html", "classstudents_1_1models_1_1_education" ],
    [ "Position", "classstudents_1_1models_1_1_position.html", "classstudents_1_1models_1_1_position" ],
    [ "get_file_path", "models_8py.html#abcc46854fc7fca904e6449a9dbecb9c1", null ],
    [ "get_image_path", "models_8py.html#aa9c9d7bfb7f8035d5302d6adbaa78be2", null ],
    [ "insert_linkedin_profile", "models_8py.html#ae5c93301e2a2e140c9b76452f5b2c79d", null ]
];