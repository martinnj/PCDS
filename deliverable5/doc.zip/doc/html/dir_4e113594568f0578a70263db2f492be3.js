var dir_4e113594568f0578a70263db2f492be3 =
[
    [ "admin.py", "admin_8py.html", [
      [ "LinkedInProfileAdmin", "classstudents_1_1admin_1_1_linked_in_profile_admin.html", null ],
      [ "SkillAdmin", "classstudents_1_1admin_1_1_skill_admin.html", null ],
      [ "LanguageAdmin", "classstudents_1_1admin_1_1_language_admin.html", null ],
      [ "EducationAdmin", "classstudents_1_1admin_1_1_education_admin.html", null ],
      [ "CourseAdmin", "classstudents_1_1admin_1_1_course_admin.html", null ],
      [ "PositionAdmin", "classstudents_1_1admin_1_1_position_admin.html", null ],
      [ "StudentAdmin", "classstudents_1_1admin_1_1_student_admin.html", null ],
      [ "StudentProjectAdmin", "classstudents_1_1admin_1_1_student_project_admin.html", null ]
    ] ],
    [ "linkedin_connector.py", "linkedin__connector_8py.html", "linkedin__connector_8py" ],
    [ "linkedin_converter.py", "linkedin__converter_8py.html", "linkedin__converter_8py" ],
    [ "matchmaking.py", "matchmaking_8py.html", "matchmaking_8py" ],
    [ "models.py", "models_8py.html", "models_8py" ],
    [ "urls.py", "urls_8py.html", null ],
    [ "views.py", "views_8py.html", "views_8py" ]
];