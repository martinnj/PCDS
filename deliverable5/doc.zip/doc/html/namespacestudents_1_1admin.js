var namespacestudents_1_1admin =
[
    [ "LinkedInProfileAdmin", "classstudents_1_1admin_1_1_linked_in_profile_admin.html", null ],
    [ "SkillAdmin", "classstudents_1_1admin_1_1_skill_admin.html", null ],
    [ "LanguageAdmin", "classstudents_1_1admin_1_1_language_admin.html", null ],
    [ "EducationAdmin", "classstudents_1_1admin_1_1_education_admin.html", null ],
    [ "CourseAdmin", "classstudents_1_1admin_1_1_course_admin.html", null ],
    [ "PositionAdmin", "classstudents_1_1admin_1_1_position_admin.html", null ],
    [ "StudentAdmin", "classstudents_1_1admin_1_1_student_admin.html", null ],
    [ "StudentProjectAdmin", "classstudents_1_1admin_1_1_student_project_admin.html", null ]
];