var classstudents_1_1models_1_1_position =
[
    [ "__unicode__", "classstudents_1_1models_1_1_position.html#a9801bf25c27f58f0d7306f8df13b400e", null ],
    [ "get_jobtitle", "classstudents_1_1models_1_1_position.html#ae6db8ec9d406188f652ec3d344f67f7b", null ]
];