var classstudents_1_1models_1_1_linked_in_profile =
[
    [ "__unicode__", "classstudents_1_1models_1_1_linked_in_profile.html#a625f309407380b0239ed0ba4a8fcd8f8", null ],
    [ "get_full_name", "classstudents_1_1models_1_1_linked_in_profile.html#af7294caa5c9dd7dc43bed9b4ff962e20", null ]
];