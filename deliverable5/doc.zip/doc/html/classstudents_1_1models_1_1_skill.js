var classstudents_1_1models_1_1_skill =
[
    [ "__unicode__", "classstudents_1_1models_1_1_skill.html#aef95ddd6ca24a649025dca066439af78", null ],
    [ "get_skill", "classstudents_1_1models_1_1_skill.html#a44f6a7c6975253c8f617f36c4400f19c", null ]
];