var classstudents_1_1views_1_1_all_project_detail_view =
[
    [ "dispatch", "classstudents_1_1views_1_1_all_project_detail_view.html#ab4579ea6b73991a980aaf7d0d7e373e8", null ],
    [ "get_context_data", "classstudents_1_1views_1_1_all_project_detail_view.html#ae9bf8cd5bb54a5b7071c273aaf2cae53", null ],
    [ "get_object", "classstudents_1_1views_1_1_all_project_detail_view.html#a501ce935af27d501442b472b27c71bda", null ]
];