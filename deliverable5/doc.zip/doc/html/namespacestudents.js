var namespacestudents =
[
    [ "admin", "namespacestudents_1_1admin.html", "namespacestudents_1_1admin" ],
    [ "linkedin_connector", "namespacestudents_1_1linkedin__connector.html", null ],
    [ "linkedin_converter", "namespacestudents_1_1linkedin__converter.html", "namespacestudents_1_1linkedin__converter" ],
    [ "matchmaking", "namespacestudents_1_1matchmaking.html", null ],
    [ "models", "namespacestudents_1_1models.html", "namespacestudents_1_1models" ],
    [ "urls", "namespacestudents_1_1urls.html", null ],
    [ "views", "namespacestudents_1_1views.html", "namespacestudents_1_1views" ]
];