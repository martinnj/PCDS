var classstudents_1_1models_1_1_course =
[
    [ "__unicode__", "classstudents_1_1models_1_1_course.html#afcde6983ecb364eb3d26811950f531b0", null ],
    [ "get_course", "classstudents_1_1models_1_1_course.html#afd219fece1d92c93deb18841782d6a16", null ]
];