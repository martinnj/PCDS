var classstudents_1_1views_1_1_student_log_in_view =
[
    [ "form_invalid", "classstudents_1_1views_1_1_student_log_in_view.html#a366b874458816a4940268304c2096fca", null ],
    [ "form_valid", "classstudents_1_1views_1_1_student_log_in_view.html#a090cfaafcae5b8aae1a89fbbd2325b63", null ]
];