var classstudents_1_1models_1_1_education =
[
    [ "__unicode__", "classstudents_1_1models_1_1_education.html#a359443228da9a61334cc9d640292b2c1", null ],
    [ "get_fieldOfStudy", "classstudents_1_1models_1_1_education.html#ac93a74960eafbe9ad36545070e2ee866", null ]
];