var namespacestudents_1_1views =
[
    [ "StudentView", "classstudents_1_1views_1_1_student_view.html", "classstudents_1_1views_1_1_student_view" ],
    [ "UpdateStudentProfileView", "classstudents_1_1views_1_1_update_student_profile_view.html", "classstudents_1_1views_1_1_update_student_profile_view" ],
    [ "StudentOwnProjectListView", "classstudents_1_1views_1_1_student_own_project_list_view.html", "classstudents_1_1views_1_1_student_own_project_list_view" ],
    [ "StudentProjectUpdateView", "classstudents_1_1views_1_1_student_project_update_view.html", "classstudents_1_1views_1_1_student_project_update_view" ],
    [ "StudentProjectDetailView", "classstudents_1_1views_1_1_student_project_detail_view.html", "classstudents_1_1views_1_1_student_project_detail_view" ],
    [ "StudentProjectCreationView", "classstudents_1_1views_1_1_student_project_creation_view.html", "classstudents_1_1views_1_1_student_project_creation_view" ],
    [ "ListAllProjectsView", "classstudents_1_1views_1_1_list_all_projects_view.html", "classstudents_1_1views_1_1_list_all_projects_view" ],
    [ "AllProjectDetailView", "classstudents_1_1views_1_1_all_project_detail_view.html", "classstudents_1_1views_1_1_all_project_detail_view" ],
    [ "StudentFAQView", "classstudents_1_1views_1_1_student_f_a_q_view.html", "classstudents_1_1views_1_1_student_f_a_q_view" ],
    [ "StudentFeedBack", "classstudents_1_1views_1_1_student_feed_back.html", "classstudents_1_1views_1_1_student_feed_back" ],
    [ "StudentTermsOfUsage", "classstudents_1_1views_1_1_student_terms_of_usage.html", null ],
    [ "SendMailView", "classstudents_1_1views_1_1_send_mail_view.html", "classstudents_1_1views_1_1_send_mail_view" ],
    [ "StudentSignUpView", "classstudents_1_1views_1_1_student_sign_up_view.html", "classstudents_1_1views_1_1_student_sign_up_view" ],
    [ "StudentLogInView", "classstudents_1_1views_1_1_student_log_in_view.html", "classstudents_1_1views_1_1_student_log_in_view" ],
    [ "ChangePasswordView", "classstudents_1_1views_1_1_change_password_view.html", "classstudents_1_1views_1_1_change_password_view" ]
];