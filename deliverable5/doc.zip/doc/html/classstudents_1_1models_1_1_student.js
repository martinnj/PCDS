var classstudents_1_1models_1_1_student =
[
    [ "__unicode__", "classstudents_1_1models_1_1_student.html#a9d4928c942577b10f9d2ba8a99c21fee", null ],
    [ "get_absolute_update_url", "classstudents_1_1models_1_1_student.html#a435641b741a8020d3abb4a356867fbb0", null ],
    [ "get_absolute_url", "classstudents_1_1models_1_1_student.html#ae9125f2c920f8b915e714d58bade580d", null ],
    [ "get_full_name", "classstudents_1_1models_1_1_student.html#acad8d7a62069a546d1e3a5f96a7fd971", null ],
    [ "get_short_name", "classstudents_1_1models_1_1_student.html#adb4699e44c6376397ce441fc8694840e", null ],
    [ "save", "classstudents_1_1models_1_1_student.html#a7d9cc5b28b8b29fafd91020c3ab7bb96", null ],
    [ "send_activation_email", "classstudents_1_1models_1_1_student.html#adb3818c664b585eecc100caf80d3f529", null ],
    [ "unique_slugify", "classstudents_1_1models_1_1_student.html#ab1ff0197cbfbdbfac52b54a9bc51e592", null ],
    [ "image", "classstudents_1_1models_1_1_student.html#a6f81eac38fb0a6074eb663b3cab8055e", null ]
];