var classstudents_1_1views_1_1_student_feed_back =
[
    [ "form_invalid", "classstudents_1_1views_1_1_student_feed_back.html#ab65735dbdc4a51b5fde3228afb3cb062", null ],
    [ "form_valid", "classstudents_1_1views_1_1_student_feed_back.html#afc5508fe4ca2258556fd31eb7d680694", null ]
];