var classstudents_1_1views_1_1_student_own_project_list_view =
[
    [ "dispatch", "classstudents_1_1views_1_1_student_own_project_list_view.html#a1914d88da030233e5bde8e9eaa672d1f", null ],
    [ "get_context_data", "classstudents_1_1views_1_1_student_own_project_list_view.html#ac4d1e0b97acee38b09e4afa6f19b5183", null ],
    [ "get_queryset", "classstudents_1_1views_1_1_student_own_project_list_view.html#a3a005eb9167f0ce90795a497f47192df", null ]
];