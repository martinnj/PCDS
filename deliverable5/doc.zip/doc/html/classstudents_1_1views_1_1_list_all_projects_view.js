var classstudents_1_1views_1_1_list_all_projects_view =
[
    [ "dispatch", "classstudents_1_1views_1_1_list_all_projects_view.html#a0d33266bd02b1a7db4bcadb7013a02ad", null ],
    [ "get_context_data", "classstudents_1_1views_1_1_list_all_projects_view.html#aa3c93985310036111318a294b02c4c6e", null ],
    [ "get_queryset", "classstudents_1_1views_1_1_list_all_projects_view.html#a97ba8473b483cd8c26dfdc1a68c71488", null ]
];